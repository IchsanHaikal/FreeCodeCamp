# The example function below keeps track of the opponent's history and plays whatever the opponent played two plays ago. It is not a very good player so you will need to change the code to pass the challenge.

def player(prev_play, opponent_history=[]):
    if prev_play:
      opponent_history.append(prev_play)
    else:
      opponent_history.clear()
      
    counter = {'S': 'R', 'P': 'S', 'R': 'P'}      
    guess = "R"
    if len(opponent_history)>=4:
      potential_play = [''.join([*opponent_history[-3:], j])
        for j in ['S', 'R', 'P']]
      play_order = [''.join(opponent_history[i:i+4]) 
        for i, j in enumerate(opponent_history[:-3])]
      sub_order = {i: play_order.count(i) for i in potential_play}
      prediction = max(sub_order, key=sub_order.get)[-1]
      guess = counter[prediction]

    return guess
